/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication4;
import java.util.Scanner;
/**
 *
 * @author estudiante
 */
public class JavaApplication4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int m;
        int c;
        
        System.out.println("ingrese valor de m");
        Scanner d1 = new Scanner(System.in);
        m = d1.nextInt();
      
        System.out.println("ingrese valor de c");
        Scanner d2 = new Scanner(System.in);
        m = d2.nextInt();
        
        System.out.println("R"+m+c/2);
    }
    
}
